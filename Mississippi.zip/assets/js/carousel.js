$('.loop').owlCarousel({
    center: true,
    items: 2,
    dots: false,
    autoplay: true,
    loop: true,
    margin: 10,
    responsive:{
        600:{
            items:4
        }
    }
});